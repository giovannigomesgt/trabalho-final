from airflow.decorators import task, dag
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from datetime import datetime
import boto3

aws_access_key_id = Variable.get('aws_access_key_id')
aws_secret_access_key = Variable.get('aws_secret_access_key')

client = boto3.client(
    'emr', region_name='us-east-1',
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key
)

default_args = {
    'owner': 'Giovanni',
    'start_date': datetime(2022, 5, 11)
}

@dag(default_args=default_args,schedule_interval="@once", description="Executa um job Spark no EMR", catchup=False, tags=['Spark','EMR','Filmes','Imdb'])
def indicadores_filmes():

    #inicio = DummyOperator(task_id='inicio')

    @task
    def inicio():
        return True

    @task
    def emr_process_filmes(success_before: bool):
        if success_before:
            newstep = client.add_job_flow_steps(
                JobFlowId="j-10V2KZMSGWIQ3",
                Steps=[
                    {
                        'Name': 'Processa dados de Filmes',
                        'ActionOnFailure': "CONTINUE",
                        'HadoopJarStep': {
                            'Jar': 'command-runner.jar',
                            'Args': ['spark-submit',
                                    '--master', 'yarn',
                                    '--deploy-mode', 'cluster',
                                    's3://emr-256240406578/code/filmes_imdb.py'
                                    ]
                        }
                    }
                ]
            )
            return newstep['StepIds'][0]

    @task
    def wait_emr_job(stepId: str):
        waiter = client.get_waiter('step_complete')
        
        waiter.wait(
            ClusterId="j-10V2KZMSGWIQ3",
            StepId=stepId,
            WaiterConfig={
                'Delay': 10,
                'MaxAttempts': 600
            }
        )
        return True

    @task
    def terminate_emr_cluster():
        response = client.terminate_job_flows(
    JobFlowIds=["j-10V2KZMSGWIQ3"]
)

    fim = DummyOperator(task_id="fim")
    
    # Orquestração
    start = inicio()
    indicadores = emr_process_filmes(start)
    wait_step = wait_emr_job(indicadores)
    wait_step >> fim

execucao = indicadores_filmes()
'''
    tarefainicial = tarefa_inicial()
    cluster = "j-2KJM6TDZ0537B" #emr_create_cluster()
    inicio >> tarefainicial >> cluster


    esperacluster = aguardando_emr_cluster(cluster)

    indicadores = emr_process_filmes(cluster) 
    esperacluster >> indicadores

    wait_step = wait_emr_job(cluster, indicadores)

    terminacluster = terminate_emr_cluster(cluster)
    wait_step >> terminacluster >> fim
    #---------------
'''
